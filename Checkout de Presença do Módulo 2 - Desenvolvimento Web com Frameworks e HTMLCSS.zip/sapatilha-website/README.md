# EU AMO SAPATILHA - Website

## Descrição do Projeto

Este é um protótipo funcional da tela inicial para a loja de sapatilhas "EU AMO SAPATILHA", desenvolvido como parte de uma atividade acadêmica sobre frameworks e desenvolvimento de interfaces web.

## Tecnologias Utilizadas

- **HTML5**: Estrutura semântica da página
- **CSS3**: Estilização personalizada e responsiva
- **Bootstrap 5**: Framework CSS para responsividade e componentes
- **JavaScript**: Interatividade e animações
- **Font Awesome**: Ícones
- **Google Fonts**: Tipografia (Poppins e Dancing Script)

## Características Implementadas

### Elementos Obrigatórios
✅ **Cabeçalho** com o nome do negócio (logo)
✅ **Seção de descrição** do negócio
✅ **Imagem ilustrativa** de sapatilhas
✅ **Botões de ação** ("Ver Coleção" e "Contato")

### Funcionalidades Adicionais
- **Design responsivo** para desktop, tablet e mobile
- **Animações CSS** e efeitos hover
- **Navegação suave** entre seções
- **Corações flutuantes** animados
- **Paleta de cores** baseada na logo da marca
- **Tipografia elegante** com fontes personalizadas
- **Seção de características** da loja
- **Rodapé** com redes sociais

## Estrutura de Arquivos

```
sapatilha-website/
├── index.html          # Página principal
├── style.css           # Estilos principais
├── responsive.css      # Estilos responsivos
├── script.js          # JavaScript para interatividade
├── logo.png           # Logo da loja
├── design-plan.md     # Planejamento do design
└── README.md          # Este arquivo
```

## Paleta de Cores

- **Primária**: #E91E63 (Rosa/Magenta)
- **Secundária**: #000000 (Preto)
- **Accent**: #FF6B9D (Rosa claro)
- **Neutras**: #FFFFFF (Branco), #F5F5F5 (Cinza claro)

## Responsividade

O site é totalmente responsivo e se adapta a diferentes tamanhos de tela:

- **Desktop**: Layout em duas colunas com animações completas
- **Tablet**: Layout adaptado com navegação otimizada
- **Mobile**: Layout em coluna única com botões empilhados

## Como Visualizar

1. Abra o arquivo `index.html` em qualquer navegador web moderno
2. O site funciona offline, sem necessidade de servidor
3. Teste a responsividade redimensionando a janela do navegador

## Recursos Visuais

- **Animações suaves** em elementos da página
- **Efeitos parallax** na imagem principal
- **Transições CSS** em botões e links
- **Corações animados** como elemento temático
- **Gradientes** e sombras para profundidade

## Compatibilidade

- ✅ Chrome/Chromium
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Dispositivos móveis (iOS/Android)

## Desenvolvido por

Este projeto foi desenvolvido como atividade acadêmica, seguindo as melhores práticas de desenvolvimento web e design responsivo.

